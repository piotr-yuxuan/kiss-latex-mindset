kiss-latex-mindset
==================

I looked around for some LaTeX framework but definitely that's not what I'd like: I prefer to keep it simple, stupid so I tried to mingle some bare commands to make an easy-to-understand mindset.

## Should be implemented

 * Conf file precedence;
 * Add rake support just like [this repo](https://github.com/threedaymonk/latex-framework);
 * Any simple idea to automate LaTeX document compositiong.

## Licence

This is a free piece of code, you can fork it as you wish.

## Contributors or Examples

 * [threedaymonk](https://github.com/threedaymonk) just gave me the idea.
